


<?php

//echo "montu sec"; 
?>


















<?php




echo base64_encode($_GET["name"]);

//header('Content-Type: application/json'); 






?>


